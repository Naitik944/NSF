gdjs.LevelCode = {};
gdjs.LevelCode.GDBossBottomArmObjects2_1final = [];

gdjs.LevelCode.GDBossTopArmObjects2_1final = [];

gdjs.LevelCode.forEachCount0_3 = 0;

gdjs.LevelCode.forEachCount1_3 = 0;

gdjs.LevelCode.forEachCount2_3 = 0;

gdjs.LevelCode.forEachCount3_3 = 0;

gdjs.LevelCode.forEachIndex3 = 0;

gdjs.LevelCode.forEachObjects3 = [];

gdjs.LevelCode.forEachTotalCount3 = 0;

gdjs.LevelCode.repeatCount5 = 0;

gdjs.LevelCode.repeatIndex5 = 0;

gdjs.LevelCode.GDPlayerObjects1= [];
gdjs.LevelCode.GDPlayerObjects2= [];
gdjs.LevelCode.GDPlayerObjects3= [];
gdjs.LevelCode.GDPlayerObjects4= [];
gdjs.LevelCode.GDPlayerObjects5= [];
gdjs.LevelCode.GDPlayerObjects6= [];
gdjs.LevelCode.GDSpaceBackgroundObjects1= [];
gdjs.LevelCode.GDSpaceBackgroundObjects2= [];
gdjs.LevelCode.GDSpaceBackgroundObjects3= [];
gdjs.LevelCode.GDSpaceBackgroundObjects4= [];
gdjs.LevelCode.GDSpaceBackgroundObjects5= [];
gdjs.LevelCode.GDSpaceBackgroundObjects6= [];
gdjs.LevelCode.GDCorridorBackgroundObjects1= [];
gdjs.LevelCode.GDCorridorBackgroundObjects2= [];
gdjs.LevelCode.GDCorridorBackgroundObjects3= [];
gdjs.LevelCode.GDCorridorBackgroundObjects4= [];
gdjs.LevelCode.GDCorridorBackgroundObjects5= [];
gdjs.LevelCode.GDCorridorBackgroundObjects6= [];
gdjs.LevelCode.GDAsteroidObjects1= [];
gdjs.LevelCode.GDAsteroidObjects2= [];
gdjs.LevelCode.GDAsteroidObjects3= [];
gdjs.LevelCode.GDAsteroidObjects4= [];
gdjs.LevelCode.GDAsteroidObjects5= [];
gdjs.LevelCode.GDAsteroidObjects6= [];
gdjs.LevelCode.GDEnemy2Objects1= [];
gdjs.LevelCode.GDEnemy2Objects2= [];
gdjs.LevelCode.GDEnemy2Objects3= [];
gdjs.LevelCode.GDEnemy2Objects4= [];
gdjs.LevelCode.GDEnemy2Objects5= [];
gdjs.LevelCode.GDEnemy2Objects6= [];
gdjs.LevelCode.GDPlayerBulletObjects1= [];
gdjs.LevelCode.GDPlayerBulletObjects2= [];
gdjs.LevelCode.GDPlayerBulletObjects3= [];
gdjs.LevelCode.GDPlayerBulletObjects4= [];
gdjs.LevelCode.GDPlayerBulletObjects5= [];
gdjs.LevelCode.GDPlayerBulletObjects6= [];
gdjs.LevelCode.GDHealthPackObjects1= [];
gdjs.LevelCode.GDHealthPackObjects2= [];
gdjs.LevelCode.GDHealthPackObjects3= [];
gdjs.LevelCode.GDHealthPackObjects4= [];
gdjs.LevelCode.GDHealthPackObjects5= [];
gdjs.LevelCode.GDHealthPackObjects6= [];
gdjs.LevelCode.GDExplosionObjects1= [];
gdjs.LevelCode.GDExplosionObjects2= [];
gdjs.LevelCode.GDExplosionObjects3= [];
gdjs.LevelCode.GDExplosionObjects4= [];
gdjs.LevelCode.GDExplosionObjects5= [];
gdjs.LevelCode.GDExplosionObjects6= [];
gdjs.LevelCode.GDEnemy3Objects1= [];
gdjs.LevelCode.GDEnemy3Objects2= [];
gdjs.LevelCode.GDEnemy3Objects3= [];
gdjs.LevelCode.GDEnemy3Objects4= [];
gdjs.LevelCode.GDEnemy3Objects5= [];
gdjs.LevelCode.GDEnemy3Objects6= [];
gdjs.LevelCode.GDEnemyBulletObjects1= [];
gdjs.LevelCode.GDEnemyBulletObjects2= [];
gdjs.LevelCode.GDEnemyBulletObjects3= [];
gdjs.LevelCode.GDEnemyBulletObjects4= [];
gdjs.LevelCode.GDEnemyBulletObjects5= [];
gdjs.LevelCode.GDEnemyBulletObjects6= [];
gdjs.LevelCode.GDEnemy1Objects1= [];
gdjs.LevelCode.GDEnemy1Objects2= [];
gdjs.LevelCode.GDEnemy1Objects3= [];
gdjs.LevelCode.GDEnemy1Objects4= [];
gdjs.LevelCode.GDEnemy1Objects5= [];
gdjs.LevelCode.GDEnemy1Objects6= [];
gdjs.LevelCode.GDAttackFlameObjects1= [];
gdjs.LevelCode.GDAttackFlameObjects2= [];
gdjs.LevelCode.GDAttackFlameObjects3= [];
gdjs.LevelCode.GDAttackFlameObjects4= [];
gdjs.LevelCode.GDAttackFlameObjects5= [];
gdjs.LevelCode.GDAttackFlameObjects6= [];
gdjs.LevelCode.GDLifebarContainerObjects1= [];
gdjs.LevelCode.GDLifebarContainerObjects2= [];
gdjs.LevelCode.GDLifebarContainerObjects3= [];
gdjs.LevelCode.GDLifebarContainerObjects4= [];
gdjs.LevelCode.GDLifebarContainerObjects5= [];
gdjs.LevelCode.GDLifebarContainerObjects6= [];
gdjs.LevelCode.GDLifebarObjects1= [];
gdjs.LevelCode.GDLifebarObjects2= [];
gdjs.LevelCode.GDLifebarObjects3= [];
gdjs.LevelCode.GDLifebarObjects4= [];
gdjs.LevelCode.GDLifebarObjects5= [];
gdjs.LevelCode.GDLifebarObjects6= [];
gdjs.LevelCode.GDPlayerAttackAreaObjects1= [];
gdjs.LevelCode.GDPlayerAttackAreaObjects2= [];
gdjs.LevelCode.GDPlayerAttackAreaObjects3= [];
gdjs.LevelCode.GDPlayerAttackAreaObjects4= [];
gdjs.LevelCode.GDPlayerAttackAreaObjects5= [];
gdjs.LevelCode.GDPlayerAttackAreaObjects6= [];
gdjs.LevelCode.GDTilesMechanical2Objects1= [];
gdjs.LevelCode.GDTilesMechanical2Objects2= [];
gdjs.LevelCode.GDTilesMechanical2Objects3= [];
gdjs.LevelCode.GDTilesMechanical2Objects4= [];
gdjs.LevelCode.GDTilesMechanical2Objects5= [];
gdjs.LevelCode.GDTilesMechanical2Objects6= [];
gdjs.LevelCode.GDTilesMechanical1Objects1= [];
gdjs.LevelCode.GDTilesMechanical1Objects2= [];
gdjs.LevelCode.GDTilesMechanical1Objects3= [];
gdjs.LevelCode.GDTilesMechanical1Objects4= [];
gdjs.LevelCode.GDTilesMechanical1Objects5= [];
gdjs.LevelCode.GDTilesMechanical1Objects6= [];
gdjs.LevelCode.GDChangeButtonObjects1= [];
gdjs.LevelCode.GDChangeButtonObjects2= [];
gdjs.LevelCode.GDChangeButtonObjects3= [];
gdjs.LevelCode.GDChangeButtonObjects4= [];
gdjs.LevelCode.GDChangeButtonObjects5= [];
gdjs.LevelCode.GDChangeButtonObjects6= [];
gdjs.LevelCode.GDBossBodyObjects1= [];
gdjs.LevelCode.GDBossBodyObjects2= [];
gdjs.LevelCode.GDBossBodyObjects3= [];
gdjs.LevelCode.GDBossBodyObjects4= [];
gdjs.LevelCode.GDBossBodyObjects5= [];
gdjs.LevelCode.GDBossBodyObjects6= [];
gdjs.LevelCode.GDBossTopArmObjects1= [];
gdjs.LevelCode.GDBossTopArmObjects2= [];
gdjs.LevelCode.GDBossTopArmObjects3= [];
gdjs.LevelCode.GDBossTopArmObjects4= [];
gdjs.LevelCode.GDBossTopArmObjects5= [];
gdjs.LevelCode.GDBossTopArmObjects6= [];
gdjs.LevelCode.GDBossBottomArmObjects1= [];
gdjs.LevelCode.GDBossBottomArmObjects2= [];
gdjs.LevelCode.GDBossBottomArmObjects3= [];
gdjs.LevelCode.GDBossBottomArmObjects4= [];
gdjs.LevelCode.GDBossBottomArmObjects5= [];
gdjs.LevelCode.GDBossBottomArmObjects6= [];
gdjs.LevelCode.GDBossSuperLaserObjects1= [];
gdjs.LevelCode.GDBossSuperLaserObjects2= [];
gdjs.LevelCode.GDBossSuperLaserObjects3= [];
gdjs.LevelCode.GDBossSuperLaserObjects4= [];
gdjs.LevelCode.GDBossSuperLaserObjects5= [];
gdjs.LevelCode.GDBossSuperLaserObjects6= [];
gdjs.LevelCode.GDBossBackgroundObjects1= [];
gdjs.LevelCode.GDBossBackgroundObjects2= [];
gdjs.LevelCode.GDBossBackgroundObjects3= [];
gdjs.LevelCode.GDBossBackgroundObjects4= [];
gdjs.LevelCode.GDBossBackgroundObjects5= [];
gdjs.LevelCode.GDBossBackgroundObjects6= [];
gdjs.LevelCode.GDFadeObjects1= [];
gdjs.LevelCode.GDFadeObjects2= [];
gdjs.LevelCode.GDFadeObjects3= [];
gdjs.LevelCode.GDFadeObjects4= [];
gdjs.LevelCode.GDFadeObjects5= [];
gdjs.LevelCode.GDFadeObjects6= [];
gdjs.LevelCode.GDGameOverObjects1= [];
gdjs.LevelCode.GDGameOverObjects2= [];
gdjs.LevelCode.GDGameOverObjects3= [];
gdjs.LevelCode.GDGameOverObjects4= [];
gdjs.LevelCode.GDGameOverObjects5= [];
gdjs.LevelCode.GDGameOverObjects6= [];

gdjs.LevelCode.conditionTrue_0 = {val:false};
gdjs.LevelCode.condition0IsTrue_0 = {val:false};
gdjs.LevelCode.condition1IsTrue_0 = {val:false};
gdjs.LevelCode.condition2IsTrue_0 = {val:false};
gdjs.LevelCode.condition3IsTrue_0 = {val:false};
gdjs.LevelCode.conditionTrue_1 = {val:false};
gdjs.LevelCode.condition0IsTrue_1 = {val:false};
gdjs.LevelCode.condition1IsTrue_1 = {val:false};
gdjs.LevelCode.condition2IsTrue_1 = {val:false};
gdjs.LevelCode.condition3IsTrue_1 = {val:false};


gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects2});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDChangeButtonObjects2Objects = Hashtable.newFrom({"ChangeButton": gdjs.LevelCode.GDChangeButtonObjects2});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerBulletObjects4Objects = Hashtable.newFrom({"PlayerBullet": gdjs.LevelCode.GDPlayerBulletObjects4});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects4});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects4});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects3});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects3});
gdjs.LevelCode.eventsList0 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtsExt__SpaceShooterControls__ShouldFire.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.LevelCode.GDAttackFlameObjects2, gdjs.LevelCode.GDAttackFlameObjects4);

gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects3, gdjs.LevelCode.GDPlayerObjects4);

gdjs.copyArray(runtimeScene.getObjects("PlayerBullet"), gdjs.LevelCode.GDPlayerBulletObjects4);
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects4[i].getBehavior("FireBullet").Fire((gdjs.LevelCode.GDPlayerObjects4[i].getPointX("Bullets")), (gdjs.LevelCode.GDPlayerObjects4[i].getPointY("Bullets")), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerBulletObjects4Objects, 0, 310, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LevelCode.GDAttackFlameObjects4.length ;i < len;++i) {
    gdjs.LevelCode.GDAttackFlameObjects4[i].hide(false);
}
}}

}


{

gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects3, gdjs.LevelCode.GDPlayerObjects4);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayerObjects4[i].getBehavior("FireBullet").HasJustFired((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects4[k] = gdjs.LevelCode.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects4.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets/audio/sfx_laser1.ogg", false, 30, 1);
}}

}


{


{
gdjs.copyArray(gdjs.LevelCode.GDAttackFlameObjects2, gdjs.LevelCode.GDAttackFlameObjects4);

gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects3, gdjs.LevelCode.GDPlayerObjects4);

{for(var i = 0, len = gdjs.LevelCode.GDAttackFlameObjects4.length ;i < len;++i) {
    gdjs.LevelCode.GDAttackFlameObjects4[i].setPosition((( gdjs.LevelCode.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerObjects4[0].getPointX("Bullets")),(( gdjs.LevelCode.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerObjects4[0].getPointY("Bullets")));
}
}}

}


{

gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects3, gdjs.LevelCode.GDPlayerObjects4);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtsExt__SpaceShooterControls__GoingUp.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects4[i].setAnimationName("SpaceshipUp");
}
}}

}


{

gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects3, gdjs.LevelCode.GDPlayerObjects4);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtsExt__SpaceShooterControls__GoingDown.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects4[i].setAnimationName("SpaceshipDown");
}
}}

}


{

/* Reuse gdjs.LevelCode.GDPlayerObjects3 */

gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = !(gdjs.evtsExt__SpaceShooterControls__GoingDown.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects3Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
gdjs.LevelCode.condition1IsTrue_0.val = !(gdjs.evtsExt__SpaceShooterControls__GoingUp.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects3Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects3[i].setAnimationName("SpaceshipIdle");
}
}}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDChangeButtonObjects2Objects = Hashtable.newFrom({"ChangeButton": gdjs.LevelCode.GDChangeButtonObjects2});
gdjs.LevelCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects2, gdjs.LevelCode.GDPlayerObjects3);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects3.length;i<l;++i) {
    if ( !(gdjs.LevelCode.GDPlayerObjects3[i].isCurrentAnimationName("SpaceshipToMech")) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects3[k] = gdjs.LevelCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects3.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.LevelCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ChangeButton"), gdjs.LevelCode.GDChangeButtonObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtsExt__SpaceShooterControls__ShouldTransform.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDChangeButtonObjects2Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects2[i].setAnimationName("SpaceshipToMech");
}
}}

}


};gdjs.LevelCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects4, gdjs.LevelCode.GDPlayerObjects5);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects5.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayerObjects5[i].getAnimationFrame() > 2 ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects5[k] = gdjs.LevelCode.GDPlayerObjects5[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects5.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlayerObjects5 */
gdjs.copyArray(gdjs.LevelCode.GDPlayerAttackAreaObjects2, gdjs.LevelCode.GDPlayerAttackAreaObjects5);

{for(var i = 0, len = gdjs.LevelCode.GDPlayerAttackAreaObjects5.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerAttackAreaObjects5[i].setPosition((( gdjs.LevelCode.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerObjects5[0].getPointX("")),(( gdjs.LevelCode.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerObjects5[0].getPointY("")));
}
}}

}


{

/* Reuse gdjs.LevelCode.GDPlayerObjects4 */

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayerObjects4[i].hasAnimationEnded() ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects4[k] = gdjs.LevelCode.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects4.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects4[i].setAnimationName("MechIdle");
}
}}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects4});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects4});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects3});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects3});
gdjs.LevelCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects3, gdjs.LevelCode.GDPlayerObjects4);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtsExt__SpaceShooterControls__GoingUp.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects4[i].setAnimationName("MechUp");
}
}}

}


{

gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects3, gdjs.LevelCode.GDPlayerObjects4);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtsExt__SpaceShooterControls__GoingDown.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects4[i].setAnimationName("MechDown");
}
}}

}


{

/* Reuse gdjs.LevelCode.GDPlayerObjects3 */

gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = !(gdjs.evtsExt__SpaceShooterControls__GoingDown.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects3Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
gdjs.LevelCode.condition1IsTrue_0.val = !(gdjs.evtsExt__SpaceShooterControls__GoingUp.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects3Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects3[i].setAnimationName("MechIdle");
}
}}

}


};gdjs.LevelCode.eventsList4 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtsExt__SpaceShooterControls__ShouldFire.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects3, gdjs.LevelCode.GDPlayerObjects4);

{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects4[i].setAnimationName("MechAttack");
}
}}

}


{

gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects3, gdjs.LevelCode.GDPlayerObjects4);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayerObjects4[i].isCurrentAnimationName("MechAttack") ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects4[k] = gdjs.LevelCode.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects4.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.LevelCode.eventsList2(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.LevelCode.GDPlayerObjects3 */

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects3.length;i<l;++i) {
    if ( !(gdjs.LevelCode.GDPlayerObjects3[i].isCurrentAnimationName("MechAttack")) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects3[k] = gdjs.LevelCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects3.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.LevelCode.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDChangeButtonObjects2Objects = Hashtable.newFrom({"ChangeButton": gdjs.LevelCode.GDChangeButtonObjects2});
gdjs.LevelCode.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects2, gdjs.LevelCode.GDPlayerObjects3);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects3.length;i<l;++i) {
    if ( !(gdjs.LevelCode.GDPlayerObjects3[i].isCurrentAnimationName("MechToSpaceship")) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects3[k] = gdjs.LevelCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects3.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.LevelCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ChangeButton"), gdjs.LevelCode.GDChangeButtonObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtsExt__SpaceShooterControls__ShouldTransform.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDChangeButtonObjects2Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects2[i].setAnimationName("MechToSpaceship");
}
}}

}


};gdjs.LevelCode.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects2, gdjs.LevelCode.GDPlayerObjects3);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayerObjects3[i].isCurrentAnimationName("SpaceshipToMech") ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects3[k] = gdjs.LevelCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects3.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects3[i].setAnimationName("MechIdle");
}
}{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects3[i].returnVariable(gdjs.LevelCode.GDPlayerObjects3[i].getVariables().getFromIndex(0)).setString("Mech");
}
}}

}


{

/* Reuse gdjs.LevelCode.GDPlayerObjects2 */

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayerObjects2[i].isCurrentAnimationName("MechToSpaceship") ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects2[k] = gdjs.LevelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects2.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects2[i].setAnimationName("SpaceshipIdle");
}
}{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects2[i].returnVariable(gdjs.LevelCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)).setString("Spaceship");
}
}}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects2});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDBossSuperLaserObjects2Objects = Hashtable.newFrom({"BossSuperLaser": gdjs.LevelCode.GDBossSuperLaserObjects2});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects2});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemyBulletObjects2Objects = Hashtable.newFrom({"EnemyBullet": gdjs.LevelCode.GDEnemyBulletObjects2});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects2Objects = Hashtable.newFrom({"Explosion": gdjs.LevelCode.GDExplosionObjects2});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects2Objects = Hashtable.newFrom({"Explosion": gdjs.LevelCode.GDExplosionObjects2});
gdjs.LevelCode.eventsList7 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
{gdjs.LevelCode.conditionTrue_1 = gdjs.LevelCode.condition0IsTrue_0;
gdjs.LevelCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12116580);
}
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects1, gdjs.LevelCode.GDPlayerObjects2);

{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects2[i].resetTimer("DeathExplosions");
}
}}

}


{

gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects1, gdjs.LevelCode.GDPlayerObjects2);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayerObjects2[i].timerElapsedTime("DeathExplosions", 0.08) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects2[k] = gdjs.LevelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects2.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlayerObjects2 */
gdjs.LevelCode.GDExplosionObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects2Objects, (( gdjs.LevelCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerObjects2[0].getPointX("")) + gdjs.random(20), (( gdjs.LevelCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerObjects2[0].getPointY("")) + gdjs.random((( gdjs.LevelCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerObjects2[0].getHeight())), "");
}{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects2[i].resetTimer("DeathExplosions");
}
}}

}


{


{
}

}


};gdjs.LevelCode.eventsList8 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerAttackArea"), gdjs.LevelCode.GDPlayerAttackAreaObjects2);
{for(var i = 0, len = gdjs.LevelCode.GDPlayerAttackAreaObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerAttackAreaObjects2[i].hide();
}
}{gdjs.adMob.loadAppOpen("ca-app-pub-5890513729423190/7048177353", "", true, true);
}}

}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) != 1;
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ChangeButton"), gdjs.LevelCode.GDChangeButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects2);
{gdjs.evtsExt__SpaceShooterControls__HandlePlayerMovement.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects2Objects, "TopDownMovement", gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDChangeButtonObjects2Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayerObjects2[i].getVariableString(gdjs.LevelCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == "Spaceship" ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects2[k] = gdjs.LevelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects2.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("AttackFlame"), gdjs.LevelCode.GDAttackFlameObjects2);
{for(var i = 0, len = gdjs.LevelCode.GDAttackFlameObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDAttackFlameObjects2[i].hide();
}
}
{ //Subevents
gdjs.LevelCode.eventsList1(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayerObjects2[i].getVariableString(gdjs.LevelCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == "Mech" ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects2[k] = gdjs.LevelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects2.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerAttackArea"), gdjs.LevelCode.GDPlayerAttackAreaObjects2);
{for(var i = 0, len = gdjs.LevelCode.GDPlayerAttackAreaObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerAttackAreaObjects2[i].setPosition(0,0);
}
}
{ //Subevents
gdjs.LevelCode.eventsList5(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayerObjects2[i].hasAnimationEnded() ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects2[k] = gdjs.LevelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects2.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.LevelCode.eventsList6(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("BossSuperLaser"), gdjs.LevelCode.GDBossSuperLaserObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects2Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDBossSuperLaserObjects2Objects, false, runtimeScene, false);
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects2[i].getBehavior("Health").Hit(40, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.LevelCode.GDEnemyBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects2Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemyBulletObjects2Objects, false, runtimeScene, false);
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDEnemyBulletObjects2 */
/* Reuse gdjs.LevelCode.GDPlayerObjects2 */
gdjs.LevelCode.GDExplosionObjects2.length = 0;

{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects2[i].getBehavior("Health").Hit(10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects2Objects, (( gdjs.LevelCode.GDEnemyBulletObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDEnemyBulletObjects2[0].getPointX("")) + 5, (( gdjs.LevelCode.GDEnemyBulletObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDEnemyBulletObjects2[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.LevelCode.GDEnemyBulletObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemyBulletObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayerObjects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects2[k] = gdjs.LevelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects2.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects2[i].getBehavior("Flash").Flash(0.8, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets/audio/sfx_shieldDown.ogg", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayerObjects2[i].getBehavior("Flash").IsFlashing((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects2[k] = gdjs.LevelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects2.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtsExt__VibratingCamera__VibrateCameraAroundPosition.func(runtimeScene, gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2, 0, 1, 60, "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( !(gdjs.LevelCode.GDPlayerObjects2[i].getBehavior("Flash").IsFlashing((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects2[k] = gdjs.LevelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects2.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.setCameraY(runtimeScene, gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2, "", 0);
}}

}


{



}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 1;
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("SpaceBackground"), gdjs.LevelCode.GDSpaceBackgroundObjects2);
{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + (20 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)), "", 0);
}{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects2[i].addForce(20, 0, 0);
}
}{for(var i = 0, len = gdjs.LevelCode.GDSpaceBackgroundObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDSpaceBackgroundObjects2[i].setXOffset(gdjs.LevelCode.GDSpaceBackgroundObjects2[i].getXOffset() + (10 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayerObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects1[k] = gdjs.LevelCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects1.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(1);
}
{ //Subevents
gdjs.LevelCode.eventsList7(runtimeScene);} //End of subevents
}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemyBulletObjects2Objects = Hashtable.newFrom({"EnemyBullet": gdjs.LevelCode.GDEnemyBulletObjects2});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects2});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemy2Objects2ObjectsGDgdjs_46LevelCode_46GDAsteroidObjects2ObjectsGDgdjs_46LevelCode_46GDEnemy3Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy1Objects2Objects = Hashtable.newFrom({"Enemy2": gdjs.LevelCode.GDEnemy2Objects2, "Asteroid": gdjs.LevelCode.GDAsteroidObjects2, "Enemy3": gdjs.LevelCode.GDEnemy3Objects2, "Enemy1": gdjs.LevelCode.GDEnemy1Objects2});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemy2Objects2ObjectsGDgdjs_46LevelCode_46GDAsteroidObjects2ObjectsGDgdjs_46LevelCode_46GDEnemy3Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy1Objects2Objects = Hashtable.newFrom({"Enemy2": gdjs.LevelCode.GDEnemy2Objects2, "Asteroid": gdjs.LevelCode.GDAsteroidObjects2, "Enemy3": gdjs.LevelCode.GDEnemy3Objects2, "Enemy1": gdjs.LevelCode.GDEnemy1Objects2});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerBulletObjects2Objects = Hashtable.newFrom({"PlayerBullet": gdjs.LevelCode.GDPlayerBulletObjects2});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects2Objects = Hashtable.newFrom({"Explosion": gdjs.LevelCode.GDExplosionObjects2});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemy2Objects2ObjectsGDgdjs_46LevelCode_46GDAsteroidObjects2ObjectsGDgdjs_46LevelCode_46GDEnemy3Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy1Objects2Objects = Hashtable.newFrom({"Enemy2": gdjs.LevelCode.GDEnemy2Objects2, "Asteroid": gdjs.LevelCode.GDAsteroidObjects2, "Enemy3": gdjs.LevelCode.GDEnemy3Objects2, "Enemy1": gdjs.LevelCode.GDEnemy1Objects2});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerAttackAreaObjects2Objects = Hashtable.newFrom({"PlayerAttackArea": gdjs.LevelCode.GDPlayerAttackAreaObjects2});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects5Objects = Hashtable.newFrom({"Explosion": gdjs.LevelCode.GDExplosionObjects5});
gdjs.LevelCode.eventsList9 = function(runtimeScene) {

};gdjs.LevelCode.eventsList10 = function(runtimeScene) {

{


gdjs.LevelCode.repeatCount5 = 3;
for(gdjs.LevelCode.repeatIndex5 = 0;gdjs.LevelCode.repeatIndex5 < gdjs.LevelCode.repeatCount5;++gdjs.LevelCode.repeatIndex5) {
gdjs.copyArray(gdjs.LevelCode.GDAsteroidObjects3, gdjs.LevelCode.GDAsteroidObjects5);

gdjs.copyArray(gdjs.LevelCode.GDEnemy1Objects3, gdjs.LevelCode.GDEnemy1Objects5);

gdjs.copyArray(gdjs.LevelCode.GDEnemy2Objects3, gdjs.LevelCode.GDEnemy2Objects5);

gdjs.copyArray(gdjs.LevelCode.GDEnemy3Objects3, gdjs.LevelCode.GDEnemy3Objects5);

gdjs.LevelCode.GDExplosionObjects5.length = 0;


if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects5Objects, (( gdjs.LevelCode.GDEnemy1Objects5.length === 0 ) ? (( gdjs.LevelCode.GDEnemy3Objects5.length === 0 ) ? (( gdjs.LevelCode.GDAsteroidObjects5.length === 0 ) ? (( gdjs.LevelCode.GDEnemy2Objects5.length === 0 ) ? 0 :gdjs.LevelCode.GDEnemy2Objects5[0].getPointX("")) :gdjs.LevelCode.GDAsteroidObjects5[0].getPointX("")) :gdjs.LevelCode.GDEnemy3Objects5[0].getPointX("")) :gdjs.LevelCode.GDEnemy1Objects5[0].getPointX("")) + gdjs.randomInRange(-(10), 10), (( gdjs.LevelCode.GDEnemy1Objects5.length === 0 ) ? (( gdjs.LevelCode.GDEnemy3Objects5.length === 0 ) ? (( gdjs.LevelCode.GDAsteroidObjects5.length === 0 ) ? (( gdjs.LevelCode.GDEnemy2Objects5.length === 0 ) ? 0 :gdjs.LevelCode.GDEnemy2Objects5[0].getPointY("")) :gdjs.LevelCode.GDAsteroidObjects5[0].getPointY("")) :gdjs.LevelCode.GDEnemy3Objects5[0].getPointY("")) :gdjs.LevelCode.GDEnemy1Objects5[0].getPointY("")) + gdjs.randomInRange(-(10), 10), "");
}}
}

}


};gdjs.LevelCode.eventsList11 = function(runtimeScene) {

{

/* Reuse gdjs.LevelCode.GDAsteroidObjects2 */
/* Reuse gdjs.LevelCode.GDEnemy1Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy2Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy3Objects2 */

gdjs.LevelCode.forEachTotalCount3 = 0;
gdjs.LevelCode.forEachObjects3.length = 0;
gdjs.LevelCode.forEachCount0_3 = gdjs.LevelCode.GDEnemy2Objects2.length;
gdjs.LevelCode.forEachTotalCount3 += gdjs.LevelCode.forEachCount0_3;
gdjs.LevelCode.forEachObjects3.push.apply(gdjs.LevelCode.forEachObjects3,gdjs.LevelCode.GDEnemy2Objects2);
gdjs.LevelCode.forEachCount1_3 = gdjs.LevelCode.GDAsteroidObjects2.length;
gdjs.LevelCode.forEachTotalCount3 += gdjs.LevelCode.forEachCount1_3;
gdjs.LevelCode.forEachObjects3.push.apply(gdjs.LevelCode.forEachObjects3,gdjs.LevelCode.GDAsteroidObjects2);
gdjs.LevelCode.forEachCount2_3 = gdjs.LevelCode.GDEnemy3Objects2.length;
gdjs.LevelCode.forEachTotalCount3 += gdjs.LevelCode.forEachCount2_3;
gdjs.LevelCode.forEachObjects3.push.apply(gdjs.LevelCode.forEachObjects3,gdjs.LevelCode.GDEnemy3Objects2);
gdjs.LevelCode.forEachCount3_3 = gdjs.LevelCode.GDEnemy1Objects2.length;
gdjs.LevelCode.forEachTotalCount3 += gdjs.LevelCode.forEachCount3_3;
gdjs.LevelCode.forEachObjects3.push.apply(gdjs.LevelCode.forEachObjects3,gdjs.LevelCode.GDEnemy1Objects2);
for(gdjs.LevelCode.forEachIndex3 = 0;gdjs.LevelCode.forEachIndex3 < gdjs.LevelCode.forEachTotalCount3;++gdjs.LevelCode.forEachIndex3) {
gdjs.LevelCode.GDAsteroidObjects3.length = 0;

gdjs.LevelCode.GDEnemy1Objects3.length = 0;

gdjs.LevelCode.GDEnemy2Objects3.length = 0;

gdjs.LevelCode.GDEnemy3Objects3.length = 0;


if (gdjs.LevelCode.forEachIndex3 < gdjs.LevelCode.forEachCount0_3) {
    gdjs.LevelCode.GDEnemy2Objects3.push(gdjs.LevelCode.forEachObjects3[gdjs.LevelCode.forEachIndex3]);
}
else if (gdjs.LevelCode.forEachIndex3 < gdjs.LevelCode.forEachCount0_3+gdjs.LevelCode.forEachCount1_3) {
    gdjs.LevelCode.GDAsteroidObjects3.push(gdjs.LevelCode.forEachObjects3[gdjs.LevelCode.forEachIndex3]);
}
else if (gdjs.LevelCode.forEachIndex3 < gdjs.LevelCode.forEachCount0_3+gdjs.LevelCode.forEachCount1_3+gdjs.LevelCode.forEachCount2_3) {
    gdjs.LevelCode.GDEnemy3Objects3.push(gdjs.LevelCode.forEachObjects3[gdjs.LevelCode.forEachIndex3]);
}
else if (gdjs.LevelCode.forEachIndex3 < gdjs.LevelCode.forEachCount0_3+gdjs.LevelCode.forEachCount1_3+gdjs.LevelCode.forEachCount2_3+gdjs.LevelCode.forEachCount3_3) {
    gdjs.LevelCode.GDEnemy1Objects3.push(gdjs.LevelCode.forEachObjects3[gdjs.LevelCode.forEachIndex3]);
}
if (true) {

{ //Subevents: 
gdjs.LevelCode.eventsList10(runtimeScene);} //Subevents end.
}
}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects2Objects = Hashtable.newFrom({"Explosion": gdjs.LevelCode.GDExplosionObjects2});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects2Objects = Hashtable.newFrom({"Explosion": gdjs.LevelCode.GDExplosionObjects2});
gdjs.LevelCode.eventsList12 = function(runtimeScene) {

{



}


{


{
gdjs.copyArray(gdjs.LevelCode.GDEnemy3Objects1, gdjs.LevelCode.GDEnemy3Objects2);

gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.LevelCode.GDEnemyBulletObjects2);
{for(var i = 0, len = gdjs.LevelCode.GDEnemy3Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy3Objects2[i].getBehavior("FireBullet").Fire((gdjs.LevelCode.GDEnemy3Objects2[i].getPointX("Bullets")), (gdjs.LevelCode.GDEnemy3Objects2[i].getPointY("Bullets")), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemyBulletObjects2Objects, 180, 150, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


{
gdjs.copyArray(gdjs.LevelCode.GDEnemy1Objects1, gdjs.LevelCode.GDEnemy1Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy2Objects1, gdjs.LevelCode.GDEnemy2Objects2);

{for(var i = 0, len = gdjs.LevelCode.GDEnemy1Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy1Objects2[i].activateBehavior("BackAndForthMirroredMovement", true);
}
}{for(var i = 0, len = gdjs.LevelCode.GDEnemy2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy2Objects2[i].activateBehavior("LinearMovement", true);
}
}}

}


{



}


{

gdjs.copyArray(gdjs.LevelCode.GDAsteroidObjects1, gdjs.LevelCode.GDAsteroidObjects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy1Objects1, gdjs.LevelCode.GDEnemy1Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy2Objects1, gdjs.LevelCode.GDEnemy2Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy3Objects1, gdjs.LevelCode.GDEnemy3Objects2);

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects2Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemy2Objects2ObjectsGDgdjs_46LevelCode_46GDAsteroidObjects2ObjectsGDgdjs_46LevelCode_46GDEnemy3Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy1Objects2Objects, false, runtimeScene, false);
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDAsteroidObjects2 */
/* Reuse gdjs.LevelCode.GDEnemy1Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy2Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy3Objects2 */
/* Reuse gdjs.LevelCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDEnemy2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy2Objects2[i].getBehavior("Health").Hit(200, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDAsteroidObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDAsteroidObjects2[i].getBehavior("Health").Hit(200, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy3Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy3Objects2[i].getBehavior("Health").Hit(200, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy1Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy1Objects2[i].getBehavior("Health").Hit(200, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects2[i].getBehavior("Health").Hit(20, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(gdjs.LevelCode.GDAsteroidObjects1, gdjs.LevelCode.GDAsteroidObjects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy1Objects1, gdjs.LevelCode.GDEnemy1Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy2Objects1, gdjs.LevelCode.GDEnemy2Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy3Objects1, gdjs.LevelCode.GDEnemy3Objects2);

gdjs.copyArray(runtimeScene.getObjects("PlayerBullet"), gdjs.LevelCode.GDPlayerBulletObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemy2Objects2ObjectsGDgdjs_46LevelCode_46GDAsteroidObjects2ObjectsGDgdjs_46LevelCode_46GDEnemy3Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy1Objects2Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerBulletObjects2Objects, false, runtimeScene, false);
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDAsteroidObjects2 */
/* Reuse gdjs.LevelCode.GDEnemy1Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy2Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy3Objects2 */
/* Reuse gdjs.LevelCode.GDPlayerBulletObjects2 */
gdjs.LevelCode.GDExplosionObjects2.length = 0;

{for(var i = 0, len = gdjs.LevelCode.GDEnemy2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy2Objects2[i].getBehavior("Health").Hit(10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDAsteroidObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDAsteroidObjects2[i].getBehavior("Health").Hit(10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy3Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy3Objects2[i].getBehavior("Health").Hit(10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy1Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy1Objects2[i].getBehavior("Health").Hit(10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects2Objects, (( gdjs.LevelCode.GDPlayerBulletObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerBulletObjects2[0].getPointX("")) + 5, (( gdjs.LevelCode.GDPlayerBulletObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerBulletObjects2[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.LevelCode.GDPlayerBulletObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerBulletObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(gdjs.LevelCode.GDAsteroidObjects1, gdjs.LevelCode.GDAsteroidObjects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy1Objects1, gdjs.LevelCode.GDEnemy1Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy2Objects1, gdjs.LevelCode.GDEnemy2Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy3Objects1, gdjs.LevelCode.GDEnemy3Objects2);

gdjs.copyArray(runtimeScene.getObjects("PlayerAttackArea"), gdjs.LevelCode.GDPlayerAttackAreaObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemy2Objects2ObjectsGDgdjs_46LevelCode_46GDAsteroidObjects2ObjectsGDgdjs_46LevelCode_46GDEnemy3Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy1Objects2Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerAttackAreaObjects2Objects, false, runtimeScene, false);
}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
{gdjs.LevelCode.conditionTrue_1 = gdjs.LevelCode.condition1IsTrue_0;
gdjs.LevelCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12106892);
}
}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDAsteroidObjects2 */
/* Reuse gdjs.LevelCode.GDEnemy1Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy2Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy3Objects2 */
{for(var i = 0, len = gdjs.LevelCode.GDEnemy2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy2Objects2[i].getBehavior("Health").Hit(50, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDAsteroidObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDAsteroidObjects2[i].getBehavior("Health").Hit(50, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy3Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy3Objects2[i].getBehavior("Health").Hit(50, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy1Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy1Objects2[i].getBehavior("Health").Hit(50, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.LevelCode.eventsList11(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.LevelCode.GDAsteroidObjects1, gdjs.LevelCode.GDAsteroidObjects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy1Objects1, gdjs.LevelCode.GDEnemy1Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy2Objects1, gdjs.LevelCode.GDEnemy2Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy3Objects1, gdjs.LevelCode.GDEnemy3Objects2);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy2Objects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy2Objects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy2Objects2[k] = gdjs.LevelCode.GDEnemy2Objects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDAsteroidObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDAsteroidObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDAsteroidObjects2[k] = gdjs.LevelCode.GDAsteroidObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDAsteroidObjects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy3Objects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy3Objects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy3Objects2[k] = gdjs.LevelCode.GDEnemy3Objects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy3Objects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy1Objects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy1Objects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy1Objects2[k] = gdjs.LevelCode.GDEnemy1Objects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy1Objects2.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDAsteroidObjects2 */
/* Reuse gdjs.LevelCode.GDEnemy1Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy2Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy3Objects2 */
gdjs.LevelCode.GDExplosionObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects2Objects, (( gdjs.LevelCode.GDEnemy1Objects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy3Objects2.length === 0 ) ? (( gdjs.LevelCode.GDAsteroidObjects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy2Objects2.length === 0 ) ? 0 :gdjs.LevelCode.GDEnemy2Objects2[0].getPointX("")) :gdjs.LevelCode.GDAsteroidObjects2[0].getPointX("")) :gdjs.LevelCode.GDEnemy3Objects2[0].getPointX("")) :gdjs.LevelCode.GDEnemy1Objects2[0].getPointX("")) + gdjs.randomInRange(-(10), 10), (( gdjs.LevelCode.GDEnemy1Objects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy3Objects2.length === 0 ) ? (( gdjs.LevelCode.GDAsteroidObjects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy2Objects2.length === 0 ) ? 0 :gdjs.LevelCode.GDEnemy2Objects2[0].getPointY("")) :gdjs.LevelCode.GDAsteroidObjects2[0].getPointY("")) :gdjs.LevelCode.GDEnemy3Objects2[0].getPointY("")) :gdjs.LevelCode.GDEnemy1Objects2[0].getPointY("")) + gdjs.randomInRange(-(10), 10), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects2Objects, (( gdjs.LevelCode.GDEnemy1Objects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy3Objects2.length === 0 ) ? (( gdjs.LevelCode.GDAsteroidObjects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy2Objects2.length === 0 ) ? 0 :gdjs.LevelCode.GDEnemy2Objects2[0].getPointX("")) :gdjs.LevelCode.GDAsteroidObjects2[0].getPointX("")) :gdjs.LevelCode.GDEnemy3Objects2[0].getPointX("")) :gdjs.LevelCode.GDEnemy1Objects2[0].getPointX("")) + gdjs.randomInRange(-(10), 10), (( gdjs.LevelCode.GDEnemy1Objects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy3Objects2.length === 0 ) ? (( gdjs.LevelCode.GDAsteroidObjects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy2Objects2.length === 0 ) ? 0 :gdjs.LevelCode.GDEnemy2Objects2[0].getPointY("")) :gdjs.LevelCode.GDAsteroidObjects2[0].getPointY("")) :gdjs.LevelCode.GDEnemy3Objects2[0].getPointY("")) :gdjs.LevelCode.GDEnemy1Objects2[0].getPointY("")) + gdjs.randomInRange(-(10), 10), "");
}{for(var i = 0, len = gdjs.LevelCode.GDEnemy2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy2Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDAsteroidObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDAsteroidObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy3Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy3Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy1Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy1Objects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets/audio/sfx_twoTone.ogg", false, 100, 1);
}}

}


{

/* Reuse gdjs.LevelCode.GDAsteroidObjects1 */
/* Reuse gdjs.LevelCode.GDEnemy1Objects1 */
/* Reuse gdjs.LevelCode.GDEnemy2Objects1 */
/* Reuse gdjs.LevelCode.GDEnemy3Objects1 */

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy2Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy2Objects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy2Objects1[k] = gdjs.LevelCode.GDEnemy2Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy2Objects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDAsteroidObjects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDAsteroidObjects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDAsteroidObjects1[k] = gdjs.LevelCode.GDAsteroidObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDAsteroidObjects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy3Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy3Objects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy3Objects1[k] = gdjs.LevelCode.GDEnemy3Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy3Objects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy1Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy1Objects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy1Objects1[k] = gdjs.LevelCode.GDEnemy1Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy1Objects1.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDAsteroidObjects1 */
/* Reuse gdjs.LevelCode.GDEnemy1Objects1 */
/* Reuse gdjs.LevelCode.GDEnemy2Objects1 */
/* Reuse gdjs.LevelCode.GDEnemy3Objects1 */
{for(var i = 0, len = gdjs.LevelCode.GDEnemy2Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy2Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDAsteroidObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDAsteroidObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy3Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy3Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy1Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy1Objects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.LevelCode.eventsList13 = function(runtimeScene) {

{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Enemy1"), gdjs.LevelCode.GDEnemy1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy2"), gdjs.LevelCode.GDEnemy2Objects2);
{for(var i = 0, len = gdjs.LevelCode.GDEnemy1Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy1Objects2[i].activateBehavior("BackAndForthMirroredMovement", false);
}
}{for(var i = 0, len = gdjs.LevelCode.GDEnemy2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy2Objects2[i].activateBehavior("LinearMovement", false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Asteroid"), gdjs.LevelCode.GDAsteroidObjects1);
gdjs.copyArray(runtimeScene.getObjects("Enemy1"), gdjs.LevelCode.GDEnemy1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Enemy2"), gdjs.LevelCode.GDEnemy2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Enemy3"), gdjs.LevelCode.GDEnemy3Objects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy2Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy2Objects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy2Objects1[k] = gdjs.LevelCode.GDEnemy2Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy2Objects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDAsteroidObjects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDAsteroidObjects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDAsteroidObjects1[k] = gdjs.LevelCode.GDAsteroidObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDAsteroidObjects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy3Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy3Objects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy3Objects1[k] = gdjs.LevelCode.GDEnemy3Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy3Objects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy1Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy1Objects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy1Objects1[k] = gdjs.LevelCode.GDEnemy1Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy1Objects1.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.LevelCode.eventsList12(runtimeScene);} //End of subevents
}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects1});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDHealthPackObjects1Objects = Hashtable.newFrom({"HealthPack": gdjs.LevelCode.GDHealthPackObjects1});
gdjs.LevelCode.eventsList14 = function(runtimeScene) {

{

/* Reuse gdjs.LevelCode.GDHealthPackObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects1Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDHealthPackObjects1Objects, false, runtimeScene, false);
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDHealthPackObjects1 */
/* Reuse gdjs.LevelCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects1[i].getBehavior("Health").Heal(50, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LevelCode.GDHealthPackObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDHealthPackObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets/audio/Heal.wav", false, 100, 1);
}}

}


};gdjs.LevelCode.eventsList15 = function(runtimeScene) {

{



}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("HealthPack"), gdjs.LevelCode.GDHealthPackObjects2);
{for(var i = 0, len = gdjs.LevelCode.GDHealthPackObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDHealthPackObjects2[i].activateBehavior("SineMovement", false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("HealthPack"), gdjs.LevelCode.GDHealthPackObjects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDHealthPackObjects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDHealthPackObjects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDHealthPackObjects1[k] = gdjs.LevelCode.GDHealthPackObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDHealthPackObjects1.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDHealthPackObjects1 */
{for(var i = 0, len = gdjs.LevelCode.GDHealthPackObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDHealthPackObjects1[i].activateBehavior("SineMovement", true);
}
}
{ //Subevents
gdjs.LevelCode.eventsList14(runtimeScene);} //End of subevents
}

}


};gdjs.LevelCode.eventsList16 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Explosion"), gdjs.LevelCode.GDExplosionObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDExplosionObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDExplosionObjects2[i].hasAnimationEnded() ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDExplosionObjects2[k] = gdjs.LevelCode.GDExplosionObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDExplosionObjects2.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDExplosionObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDExplosionObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDExplosionObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Explosion"), gdjs.LevelCode.GDExplosionObjects1);
{for(var i = 0, len = gdjs.LevelCode.GDExplosionObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDExplosionObjects1[i].setZOrder(50);
}
}}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDFadeObjects2Objects = Hashtable.newFrom({"Fade": gdjs.LevelCode.GDFadeObjects2});
gdjs.LevelCode.eventsList17 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
{gdjs.LevelCode.conditionTrue_1 = gdjs.LevelCode.condition0IsTrue_0;
gdjs.LevelCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9528324);
}
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "GameOver");
}}

}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 3, "GameOver");
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level", false);
}}

}


};gdjs.LevelCode.eventsList18 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
{gdjs.LevelCode.conditionTrue_1 = gdjs.LevelCode.condition0IsTrue_0;
gdjs.LevelCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9530284);
}
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "LevelComplete");
}}

}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 4, "LevelComplete");
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level", false);
}}

}


};gdjs.LevelCode.eventsList19 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Lifebar"), gdjs.LevelCode.GDLifebarObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.LevelCode.GDLifebarObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDLifebarObjects2[i].setScaleX((( gdjs.LevelCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) / 100);
}
}}

}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GameOver"), gdjs.LevelCode.GDGameOverObjects2);
gdjs.LevelCode.GDFadeObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDFadeObjects2Objects, 0, 0, "UI");
}{for(var i = 0, len = gdjs.LevelCode.GDFadeObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDFadeObjects2[i].setWidth(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene));
}
}{for(var i = 0, len = gdjs.LevelCode.GDFadeObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDFadeObjects2[i].setHeight(gdjs.evtTools.window.getGameResolutionHeight(runtimeScene));
}
}{for(var i = 0, len = gdjs.LevelCode.GDFadeObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDFadeObjects2[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.LevelCode.GDFadeObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDFadeObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.LevelCode.GDGameOverObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDGameOverObjects2[i].hide();
}
}}

}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) == 1;
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Fade"), gdjs.LevelCode.GDFadeObjects2);
gdjs.copyArray(runtimeScene.getObjects("GameOver"), gdjs.LevelCode.GDGameOverObjects2);
{for(var i = 0, len = gdjs.LevelCode.GDFadeObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDFadeObjects2[i].setOpacity(gdjs.LevelCode.GDFadeObjects2[i].getOpacity() + (128 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}{for(var i = 0, len = gdjs.LevelCode.GDFadeObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDFadeObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.LevelCode.GDGameOverObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDGameOverObjects2[i].hide(false);
}
}
{ //Subevents
gdjs.LevelCode.eventsList17(runtimeScene);} //End of subevents
}

}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 1;
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Fade"), gdjs.LevelCode.GDFadeObjects1);
{for(var i = 0, len = gdjs.LevelCode.GDFadeObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDFadeObjects1[i].setOpacity(gdjs.LevelCode.GDFadeObjects1[i].getOpacity() + (128 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}{for(var i = 0, len = gdjs.LevelCode.GDFadeObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDFadeObjects1[i].hide(false);
}
}
{ //Subevents
gdjs.LevelCode.eventsList18(runtimeScene);} //End of subevents
}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDBossTopArmObjects2ObjectsGDgdjs_46LevelCode_46GDBossBottomArmObjects2Objects = Hashtable.newFrom({"BossTopArm": gdjs.LevelCode.GDBossTopArmObjects2, "BossBottomArm": gdjs.LevelCode.GDBossBottomArmObjects2});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerBulletObjects2Objects = Hashtable.newFrom({"PlayerBullet": gdjs.LevelCode.GDPlayerBulletObjects2});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects2Objects = Hashtable.newFrom({"Explosion": gdjs.LevelCode.GDExplosionObjects2});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDBossTopArmObjects2ObjectsGDgdjs_46LevelCode_46GDBossBottomArmObjects2Objects = Hashtable.newFrom({"BossTopArm": gdjs.LevelCode.GDBossTopArmObjects2, "BossBottomArm": gdjs.LevelCode.GDBossBottomArmObjects2});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerAttackAreaObjects2Objects = Hashtable.newFrom({"PlayerAttackArea": gdjs.LevelCode.GDPlayerAttackAreaObjects2});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects5Objects = Hashtable.newFrom({"Explosion": gdjs.LevelCode.GDExplosionObjects5});
gdjs.LevelCode.eventsList20 = function(runtimeScene) {

};gdjs.LevelCode.eventsList21 = function(runtimeScene) {

{


gdjs.LevelCode.repeatCount5 = 3;
for(gdjs.LevelCode.repeatIndex5 = 0;gdjs.LevelCode.repeatIndex5 < gdjs.LevelCode.repeatCount5;++gdjs.LevelCode.repeatIndex5) {
gdjs.copyArray(gdjs.LevelCode.GDBossBottomArmObjects3, gdjs.LevelCode.GDBossBottomArmObjects5);

gdjs.copyArray(gdjs.LevelCode.GDBossTopArmObjects3, gdjs.LevelCode.GDBossTopArmObjects5);

gdjs.LevelCode.GDExplosionObjects5.length = 0;


if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects5Objects, (( gdjs.LevelCode.GDBossBottomArmObjects5.length === 0 ) ? (( gdjs.LevelCode.GDBossTopArmObjects5.length === 0 ) ? 0 :gdjs.LevelCode.GDBossTopArmObjects5[0].getPointX("Bullets")) :gdjs.LevelCode.GDBossBottomArmObjects5[0].getPointX("Bullets")) + gdjs.randomInRange(-(10), 10), (( gdjs.LevelCode.GDBossBottomArmObjects5.length === 0 ) ? (( gdjs.LevelCode.GDBossTopArmObjects5.length === 0 ) ? 0 :gdjs.LevelCode.GDBossTopArmObjects5[0].getPointY("Bullets")) :gdjs.LevelCode.GDBossBottomArmObjects5[0].getPointY("Bullets")) + gdjs.randomInRange(-(10), 10), "");
}}
}

}


};gdjs.LevelCode.eventsList22 = function(runtimeScene) {

{

/* Reuse gdjs.LevelCode.GDBossBottomArmObjects2 */
/* Reuse gdjs.LevelCode.GDBossTopArmObjects2 */

gdjs.LevelCode.forEachTotalCount3 = 0;
gdjs.LevelCode.forEachObjects3.length = 0;
gdjs.LevelCode.forEachCount0_3 = gdjs.LevelCode.GDBossTopArmObjects2.length;
gdjs.LevelCode.forEachTotalCount3 += gdjs.LevelCode.forEachCount0_3;
gdjs.LevelCode.forEachObjects3.push.apply(gdjs.LevelCode.forEachObjects3,gdjs.LevelCode.GDBossTopArmObjects2);
gdjs.LevelCode.forEachCount1_3 = gdjs.LevelCode.GDBossBottomArmObjects2.length;
gdjs.LevelCode.forEachTotalCount3 += gdjs.LevelCode.forEachCount1_3;
gdjs.LevelCode.forEachObjects3.push.apply(gdjs.LevelCode.forEachObjects3,gdjs.LevelCode.GDBossBottomArmObjects2);
for(gdjs.LevelCode.forEachIndex3 = 0;gdjs.LevelCode.forEachIndex3 < gdjs.LevelCode.forEachTotalCount3;++gdjs.LevelCode.forEachIndex3) {
gdjs.LevelCode.GDBossBottomArmObjects3.length = 0;

gdjs.LevelCode.GDBossTopArmObjects3.length = 0;


if (gdjs.LevelCode.forEachIndex3 < gdjs.LevelCode.forEachCount0_3) {
    gdjs.LevelCode.GDBossTopArmObjects3.push(gdjs.LevelCode.forEachObjects3[gdjs.LevelCode.forEachIndex3]);
}
else if (gdjs.LevelCode.forEachIndex3 < gdjs.LevelCode.forEachCount0_3+gdjs.LevelCode.forEachCount1_3) {
    gdjs.LevelCode.GDBossBottomArmObjects3.push(gdjs.LevelCode.forEachObjects3[gdjs.LevelCode.forEachIndex3]);
}
if (true) {

{ //Subevents: 
gdjs.LevelCode.eventsList21(runtimeScene);} //Subevents end.
}
}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDBossBodyObjects2Objects = Hashtable.newFrom({"BossBody": gdjs.LevelCode.GDBossBodyObjects2});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerBulletObjects2Objects = Hashtable.newFrom({"PlayerBullet": gdjs.LevelCode.GDPlayerBulletObjects2});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects2Objects = Hashtable.newFrom({"Explosion": gdjs.LevelCode.GDExplosionObjects2});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemyBulletObjects2Objects = Hashtable.newFrom({"EnemyBullet": gdjs.LevelCode.GDEnemyBulletObjects2});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemyBulletObjects2Objects = Hashtable.newFrom({"EnemyBullet": gdjs.LevelCode.GDEnemyBulletObjects2});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDBossSuperLaserObjects2Objects = Hashtable.newFrom({"BossSuperLaser": gdjs.LevelCode.GDBossSuperLaserObjects2});
gdjs.LevelCode.eventsList23 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BossBottomArm"), gdjs.LevelCode.GDBossBottomArmObjects2);
gdjs.copyArray(runtimeScene.getObjects("BossTopArm"), gdjs.LevelCode.GDBossTopArmObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossTopArmObjects2.length;i<l;++i) {
    if ( !(gdjs.LevelCode.GDBossTopArmObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossTopArmObjects2[k] = gdjs.LevelCode.GDBossTopArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossTopArmObjects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBottomArmObjects2.length;i<l;++i) {
    if ( !(gdjs.LevelCode.GDBossBottomArmObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBottomArmObjects2[k] = gdjs.LevelCode.GDBossBottomArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBottomArmObjects2.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossBottomArmObjects2 */
/* Reuse gdjs.LevelCode.GDBossTopArmObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDBossTopArmObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossTopArmObjects2[i].setAnimationName("Deploy");
}
for(var i = 0, len = gdjs.LevelCode.GDBossBottomArmObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossBottomArmObjects2[i].setAnimationName("Deploy");
}
}}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects1Objects = Hashtable.newFrom({"Explosion": gdjs.LevelCode.GDExplosionObjects1});
gdjs.LevelCode.eventsList24 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
{gdjs.LevelCode.conditionTrue_1 = gdjs.LevelCode.condition0IsTrue_0;
gdjs.LevelCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9555484);
}
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.LevelCode.GDBossBodyObjects1, gdjs.LevelCode.GDBossBodyObjects2);

{for(var i = 0, len = gdjs.LevelCode.GDBossBodyObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossBodyObjects2[i].resetTimer("DeathExplosions");
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(1);
}}

}


{


{
{gdjs.evtsExt__VibratingCamera__VibrateCameraAroundPosition.func(runtimeScene, gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), 0, 1, 50, "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

/* Reuse gdjs.LevelCode.GDBossBodyObjects1 */

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBodyObjects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBodyObjects1[i].timerElapsedTime("DeathExplosions", 0.08) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBodyObjects1[k] = gdjs.LevelCode.GDBossBodyObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBodyObjects1.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossBodyObjects1 */
gdjs.LevelCode.GDExplosionObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects1Objects, (( gdjs.LevelCode.GDBossBodyObjects1.length === 0 ) ? 0 :gdjs.LevelCode.GDBossBodyObjects1[0].getPointX("")) + gdjs.random(40), (( gdjs.LevelCode.GDBossBodyObjects1.length === 0 ) ? 0 :gdjs.LevelCode.GDBossBodyObjects1[0].getPointY("")) + gdjs.random((( gdjs.LevelCode.GDBossBodyObjects1.length === 0 ) ? 0 :gdjs.LevelCode.GDBossBodyObjects1[0].getHeight())), "");
}{for(var i = 0, len = gdjs.LevelCode.GDBossBodyObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDBossBodyObjects1[i].resetTimer("DeathExplosions");
}
}}

}


};gdjs.LevelCode.eventsList25 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
{gdjs.LevelCode.conditionTrue_1 = gdjs.LevelCode.condition0IsTrue_0;
gdjs.LevelCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9533044);
}
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.LevelCode.GDBossBodyObjects1, gdjs.LevelCode.GDBossBodyObjects2);

{for(var i = 0, len = gdjs.LevelCode.GDBossBodyObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossBodyObjects2[i].resetTimer("LaserAttack");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("BossBottomArm"), gdjs.LevelCode.GDBossBottomArmObjects2);
gdjs.copyArray(runtimeScene.getObjects("BossTopArm"), gdjs.LevelCode.GDBossTopArmObjects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerBullet"), gdjs.LevelCode.GDPlayerBulletObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDBossTopArmObjects2ObjectsGDgdjs_46LevelCode_46GDBossBottomArmObjects2Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerBulletObjects2Objects, false, runtimeScene, false);
}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossTopArmObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossTopArmObjects2[i].isCurrentAnimationName("Idle") ) {
        gdjs.LevelCode.condition1IsTrue_0.val = true;
        gdjs.LevelCode.GDBossTopArmObjects2[k] = gdjs.LevelCode.GDBossTopArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossTopArmObjects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBottomArmObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBottomArmObjects2[i].isCurrentAnimationName("Idle") ) {
        gdjs.LevelCode.condition1IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBottomArmObjects2[k] = gdjs.LevelCode.GDBossBottomArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBottomArmObjects2.length = k;}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossBottomArmObjects2 */
/* Reuse gdjs.LevelCode.GDBossTopArmObjects2 */
/* Reuse gdjs.LevelCode.GDPlayerBulletObjects2 */
gdjs.LevelCode.GDExplosionObjects2.length = 0;

{for(var i = 0, len = gdjs.LevelCode.GDBossTopArmObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossTopArmObjects2[i].getBehavior("Health").Hit(10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDBossBottomArmObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossBottomArmObjects2[i].getBehavior("Health").Hit(10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects2Objects, (( gdjs.LevelCode.GDPlayerBulletObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerBulletObjects2[0].getPointX("")) + 5, (( gdjs.LevelCode.GDPlayerBulletObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerBulletObjects2[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.LevelCode.GDPlayerBulletObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerBulletObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BossBottomArm"), gdjs.LevelCode.GDBossBottomArmObjects2);
gdjs.copyArray(runtimeScene.getObjects("BossTopArm"), gdjs.LevelCode.GDBossTopArmObjects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerAttackArea"), gdjs.LevelCode.GDPlayerAttackAreaObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
gdjs.LevelCode.condition2IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDBossTopArmObjects2ObjectsGDgdjs_46LevelCode_46GDBossBottomArmObjects2Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerAttackAreaObjects2Objects, false, runtimeScene, false);
}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossTopArmObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossTopArmObjects2[i].isCurrentAnimationName("Idle") ) {
        gdjs.LevelCode.condition1IsTrue_0.val = true;
        gdjs.LevelCode.GDBossTopArmObjects2[k] = gdjs.LevelCode.GDBossTopArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossTopArmObjects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBottomArmObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBottomArmObjects2[i].isCurrentAnimationName("Idle") ) {
        gdjs.LevelCode.condition1IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBottomArmObjects2[k] = gdjs.LevelCode.GDBossBottomArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBottomArmObjects2.length = k;}if ( gdjs.LevelCode.condition1IsTrue_0.val ) {
{
{gdjs.LevelCode.conditionTrue_1 = gdjs.LevelCode.condition2IsTrue_0;
gdjs.LevelCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9536916);
}
}}
}
if (gdjs.LevelCode.condition2IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossBottomArmObjects2 */
/* Reuse gdjs.LevelCode.GDBossTopArmObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDBossTopArmObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossTopArmObjects2[i].getBehavior("Health").Hit(10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDBossBottomArmObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossBottomArmObjects2[i].getBehavior("Health").Hit(10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.LevelCode.eventsList22(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.LevelCode.GDBossBodyObjects1, gdjs.LevelCode.GDBossBodyObjects2);

gdjs.copyArray(runtimeScene.getObjects("PlayerBullet"), gdjs.LevelCode.GDPlayerBulletObjects2);
gdjs.LevelCode.GDBossBottomArmObjects2.length = 0;

gdjs.LevelCode.GDBossTopArmObjects2.length = 0;


gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDBossBodyObjects2Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerBulletObjects2Objects, false, runtimeScene, false);
}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
{gdjs.LevelCode.conditionTrue_1 = gdjs.LevelCode.condition1IsTrue_0;
gdjs.LevelCode.GDBossBottomArmObjects2_1final.length = 0;gdjs.LevelCode.GDBossTopArmObjects2_1final.length = 0;gdjs.LevelCode.condition0IsTrue_1.val = false;
gdjs.LevelCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("BossBottomArm"), gdjs.LevelCode.GDBossBottomArmObjects3);
gdjs.copyArray(runtimeScene.getObjects("BossTopArm"), gdjs.LevelCode.GDBossTopArmObjects3);
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossTopArmObjects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossTopArmObjects3[i].isCurrentAnimationName("Retract") ) {
        gdjs.LevelCode.condition0IsTrue_1.val = true;
        gdjs.LevelCode.GDBossTopArmObjects3[k] = gdjs.LevelCode.GDBossTopArmObjects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossTopArmObjects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBottomArmObjects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBottomArmObjects3[i].isCurrentAnimationName("Retract") ) {
        gdjs.LevelCode.condition0IsTrue_1.val = true;
        gdjs.LevelCode.GDBossBottomArmObjects3[k] = gdjs.LevelCode.GDBossBottomArmObjects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBottomArmObjects3.length = k;if( gdjs.LevelCode.condition0IsTrue_1.val ) {
    gdjs.LevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.LevelCode.GDBossBottomArmObjects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDBossBottomArmObjects2_1final.indexOf(gdjs.LevelCode.GDBossBottomArmObjects3[j]) === -1 )
            gdjs.LevelCode.GDBossBottomArmObjects2_1final.push(gdjs.LevelCode.GDBossBottomArmObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDBossTopArmObjects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDBossTopArmObjects2_1final.indexOf(gdjs.LevelCode.GDBossTopArmObjects3[j]) === -1 )
            gdjs.LevelCode.GDBossTopArmObjects2_1final.push(gdjs.LevelCode.GDBossTopArmObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("BossBottomArm"), gdjs.LevelCode.GDBossBottomArmObjects3);
gdjs.copyArray(runtimeScene.getObjects("BossTopArm"), gdjs.LevelCode.GDBossTopArmObjects3);
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossTopArmObjects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossTopArmObjects3[i].isCurrentAnimationName("Broken") ) {
        gdjs.LevelCode.condition1IsTrue_1.val = true;
        gdjs.LevelCode.GDBossTopArmObjects3[k] = gdjs.LevelCode.GDBossTopArmObjects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossTopArmObjects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBottomArmObjects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBottomArmObjects3[i].isCurrentAnimationName("Broken") ) {
        gdjs.LevelCode.condition1IsTrue_1.val = true;
        gdjs.LevelCode.GDBossBottomArmObjects3[k] = gdjs.LevelCode.GDBossBottomArmObjects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBottomArmObjects3.length = k;if( gdjs.LevelCode.condition1IsTrue_1.val ) {
    gdjs.LevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.LevelCode.GDBossBottomArmObjects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDBossBottomArmObjects2_1final.indexOf(gdjs.LevelCode.GDBossBottomArmObjects3[j]) === -1 )
            gdjs.LevelCode.GDBossBottomArmObjects2_1final.push(gdjs.LevelCode.GDBossBottomArmObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDBossTopArmObjects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDBossTopArmObjects2_1final.indexOf(gdjs.LevelCode.GDBossTopArmObjects3[j]) === -1 )
            gdjs.LevelCode.GDBossTopArmObjects2_1final.push(gdjs.LevelCode.GDBossTopArmObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.LevelCode.GDBossBottomArmObjects2_1final, gdjs.LevelCode.GDBossBottomArmObjects2);
gdjs.copyArray(gdjs.LevelCode.GDBossTopArmObjects2_1final, gdjs.LevelCode.GDBossTopArmObjects2);
}
}
}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossBodyObjects2 */
/* Reuse gdjs.LevelCode.GDPlayerBulletObjects2 */
gdjs.LevelCode.GDExplosionObjects2.length = 0;

{for(var i = 0, len = gdjs.LevelCode.GDBossBodyObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossBodyObjects2[i].getBehavior("Health").Hit(10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects2Objects, (( gdjs.LevelCode.GDPlayerBulletObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerBulletObjects2[0].getPointX("")) + 5, (( gdjs.LevelCode.GDPlayerBulletObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerBulletObjects2[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.LevelCode.GDPlayerBulletObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerBulletObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("BossBottomArm"), gdjs.LevelCode.GDBossBottomArmObjects2);
gdjs.copyArray(runtimeScene.getObjects("BossTopArm"), gdjs.LevelCode.GDBossTopArmObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossTopArmObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossTopArmObjects2[i].hasAnimationEnded() ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossTopArmObjects2[k] = gdjs.LevelCode.GDBossTopArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossTopArmObjects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBottomArmObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBottomArmObjects2[i].hasAnimationEnded() ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBottomArmObjects2[k] = gdjs.LevelCode.GDBossBottomArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBottomArmObjects2.length = k;}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossTopArmObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossTopArmObjects2[i].isCurrentAnimationName("Deploy") ) {
        gdjs.LevelCode.condition1IsTrue_0.val = true;
        gdjs.LevelCode.GDBossTopArmObjects2[k] = gdjs.LevelCode.GDBossTopArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossTopArmObjects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBottomArmObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBottomArmObjects2[i].isCurrentAnimationName("Deploy") ) {
        gdjs.LevelCode.condition1IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBottomArmObjects2[k] = gdjs.LevelCode.GDBossBottomArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBottomArmObjects2.length = k;}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossBottomArmObjects2 */
/* Reuse gdjs.LevelCode.GDBossTopArmObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDBossTopArmObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossTopArmObjects2[i].setAnimationName("Idle");
}
for(var i = 0, len = gdjs.LevelCode.GDBossBottomArmObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossBottomArmObjects2[i].setAnimationName("Idle");
}
}}

}


{

gdjs.copyArray(gdjs.LevelCode.GDBossBodyObjects1, gdjs.LevelCode.GDBossBodyObjects2);

gdjs.copyArray(runtimeScene.getObjects("BossBottomArm"), gdjs.LevelCode.GDBossBottomArmObjects2);
gdjs.copyArray(runtimeScene.getObjects("BossTopArm"), gdjs.LevelCode.GDBossTopArmObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossTopArmObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossTopArmObjects2[i].isCurrentAnimationName("Idle") ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossTopArmObjects2[k] = gdjs.LevelCode.GDBossTopArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossTopArmObjects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBottomArmObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBottomArmObjects2[i].isCurrentAnimationName("Idle") ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBottomArmObjects2[k] = gdjs.LevelCode.GDBossBottomArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBottomArmObjects2.length = k;}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBodyObjects2.length;i<l;++i) {
    if ( !(gdjs.LevelCode.GDBossBodyObjects2[i].timerElapsedTime("LaserAttack", 2)) ) {
        gdjs.LevelCode.condition1IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBodyObjects2[k] = gdjs.LevelCode.GDBossBodyObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBodyObjects2.length = k;}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossBottomArmObjects2 */
/* Reuse gdjs.LevelCode.GDBossTopArmObjects2 */
gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.LevelCode.GDEnemyBulletObjects2);
{for(var i = 0, len = gdjs.LevelCode.GDBossTopArmObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossTopArmObjects2[i].getBehavior("FireBullet").Fire((gdjs.LevelCode.GDBossTopArmObjects2[i].getPointX("Bullets")), (gdjs.LevelCode.GDBossTopArmObjects2[i].getPointY("Bullets")), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemyBulletObjects2Objects, 180, 150, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDBossBottomArmObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossBottomArmObjects2[i].getBehavior("FireBullet").Fire((gdjs.LevelCode.GDBossBottomArmObjects2[i].getPointX("Bullets")), (gdjs.LevelCode.GDBossBottomArmObjects2[i].getPointY("Bullets")), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemyBulletObjects2Objects, 180, 150, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LevelCode.GDEnemyBulletObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemyBulletObjects2[i].setZOrder(20);
}
}}

}


{

gdjs.copyArray(gdjs.LevelCode.GDBossBodyObjects1, gdjs.LevelCode.GDBossBodyObjects2);

gdjs.copyArray(runtimeScene.getObjects("BossBottomArm"), gdjs.LevelCode.GDBossBottomArmObjects2);
gdjs.copyArray(runtimeScene.getObjects("BossTopArm"), gdjs.LevelCode.GDBossTopArmObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
gdjs.LevelCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBodyObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBodyObjects2[i].timerElapsedTime("LaserAttack", 4) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBodyObjects2[k] = gdjs.LevelCode.GDBossBodyObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBodyObjects2.length = k;}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossTopArmObjects2.length;i<l;++i) {
    if ( !(gdjs.LevelCode.GDBossTopArmObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        gdjs.LevelCode.condition1IsTrue_0.val = true;
        gdjs.LevelCode.GDBossTopArmObjects2[k] = gdjs.LevelCode.GDBossTopArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossTopArmObjects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBottomArmObjects2.length;i<l;++i) {
    if ( !(gdjs.LevelCode.GDBossBottomArmObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        gdjs.LevelCode.condition1IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBottomArmObjects2[k] = gdjs.LevelCode.GDBossBottomArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBottomArmObjects2.length = k;}if ( gdjs.LevelCode.condition1IsTrue_0.val ) {
{
{gdjs.LevelCode.conditionTrue_1 = gdjs.LevelCode.condition2IsTrue_0;
gdjs.LevelCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9545996);
}
}}
}
if (gdjs.LevelCode.condition2IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossBottomArmObjects2 */
/* Reuse gdjs.LevelCode.GDBossTopArmObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDBossTopArmObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossTopArmObjects2[i].setAnimationName("Retract");
}
for(var i = 0, len = gdjs.LevelCode.GDBossBottomArmObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossBottomArmObjects2[i].setAnimationName("Retract");
}
}}

}


{

gdjs.copyArray(gdjs.LevelCode.GDBossBodyObjects1, gdjs.LevelCode.GDBossBodyObjects2);


gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
gdjs.LevelCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBodyObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBodyObjects2[i].timerElapsedTime("LaserAttack", 5) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBodyObjects2[k] = gdjs.LevelCode.GDBossBodyObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBodyObjects2.length = k;}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBodyObjects2.length;i<l;++i) {
    if ( !(gdjs.LevelCode.GDBossBodyObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        gdjs.LevelCode.condition1IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBodyObjects2[k] = gdjs.LevelCode.GDBossBodyObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBodyObjects2.length = k;}if ( gdjs.LevelCode.condition1IsTrue_0.val ) {
{
{gdjs.LevelCode.conditionTrue_1 = gdjs.LevelCode.condition2IsTrue_0;
gdjs.LevelCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9546964);
}
}}
}
if (gdjs.LevelCode.condition2IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossBodyObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDBossBodyObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossBodyObjects2[i].setAnimationName("Attack");
}
}}

}


{

gdjs.copyArray(gdjs.LevelCode.GDBossBodyObjects1, gdjs.LevelCode.GDBossBodyObjects2);


gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
gdjs.LevelCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBodyObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBodyObjects2[i].isCurrentAnimationName("Attack") ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBodyObjects2[k] = gdjs.LevelCode.GDBossBodyObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBodyObjects2.length = k;}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBodyObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBodyObjects2[i].hasAnimationEnded() ) {
        gdjs.LevelCode.condition1IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBodyObjects2[k] = gdjs.LevelCode.GDBossBodyObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBodyObjects2.length = k;}if ( gdjs.LevelCode.condition1IsTrue_0.val ) {
{
{gdjs.LevelCode.conditionTrue_1 = gdjs.LevelCode.condition2IsTrue_0;
gdjs.LevelCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9548004);
}
}}
}
if (gdjs.LevelCode.condition2IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossBodyObjects2 */
gdjs.LevelCode.GDBossSuperLaserObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDBossSuperLaserObjects2Objects, (( gdjs.LevelCode.GDBossBodyObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDBossBodyObjects2[0].getPointX("Center")), (( gdjs.LevelCode.GDBossBodyObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDBossBodyObjects2[0].getPointY("Center")), "");
}}

}


{

gdjs.copyArray(gdjs.LevelCode.GDBossBodyObjects1, gdjs.LevelCode.GDBossBodyObjects2);


gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
gdjs.LevelCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBodyObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBodyObjects2[i].timerElapsedTime("LaserAttack", 7) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBodyObjects2[k] = gdjs.LevelCode.GDBossBodyObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBodyObjects2.length = k;}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBodyObjects2.length;i<l;++i) {
    if ( !(gdjs.LevelCode.GDBossBodyObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        gdjs.LevelCode.condition1IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBodyObjects2[k] = gdjs.LevelCode.GDBossBodyObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBodyObjects2.length = k;}if ( gdjs.LevelCode.condition1IsTrue_0.val ) {
{
{gdjs.LevelCode.conditionTrue_1 = gdjs.LevelCode.condition2IsTrue_0;
gdjs.LevelCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9549492);
}
}}
}
if (gdjs.LevelCode.condition2IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossBodyObjects2 */
gdjs.copyArray(runtimeScene.getObjects("BossSuperLaser"), gdjs.LevelCode.GDBossSuperLaserObjects2);
{for(var i = 0, len = gdjs.LevelCode.GDBossBodyObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossBodyObjects2[i].setAnimationName("Idle");
}
}{for(var i = 0, len = gdjs.LevelCode.GDBossSuperLaserObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossSuperLaserObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(gdjs.LevelCode.GDBossBodyObjects1, gdjs.LevelCode.GDBossBodyObjects2);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBodyObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBodyObjects2[i].timerElapsedTime("LaserAttack", 7.5) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBodyObjects2[k] = gdjs.LevelCode.GDBossBodyObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBodyObjects2.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossBodyObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDBossBodyObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossBodyObjects2[i].resetTimer("LaserAttack");
}
}
{ //Subevents
gdjs.LevelCode.eventsList23(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("BossBottomArm"), gdjs.LevelCode.GDBossBottomArmObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBottomArmObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBottomArmObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBottomArmObjects2[k] = gdjs.LevelCode.GDBossBottomArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBottomArmObjects2.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossBottomArmObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDBossBottomArmObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossBottomArmObjects2[i].setAnimationName("Broken");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BossTopArm"), gdjs.LevelCode.GDBossTopArmObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossTopArmObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossTopArmObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossTopArmObjects2[k] = gdjs.LevelCode.GDBossTopArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossTopArmObjects2.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossTopArmObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDBossTopArmObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossTopArmObjects2[i].setAnimationName("Broken");
}
}}

}


{

gdjs.copyArray(gdjs.LevelCode.GDBossBodyObjects1, gdjs.LevelCode.GDBossBodyObjects2);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBodyObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBodyObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBodyObjects2[k] = gdjs.LevelCode.GDBossBodyObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBodyObjects2.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossBodyObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDBossBodyObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossBodyObjects2[i].setAnimationName("Broken");
}
}}

}


{

/* Reuse gdjs.LevelCode.GDBossBodyObjects1 */
gdjs.copyArray(runtimeScene.getObjects("BossBottomArm"), gdjs.LevelCode.GDBossBottomArmObjects1);
gdjs.copyArray(runtimeScene.getObjects("BossTopArm"), gdjs.LevelCode.GDBossTopArmObjects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
gdjs.LevelCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBodyObjects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBodyObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBodyObjects1[k] = gdjs.LevelCode.GDBossBodyObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBodyObjects1.length = k;}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBottomArmObjects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBottomArmObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition1IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBottomArmObjects1[k] = gdjs.LevelCode.GDBossBottomArmObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBottomArmObjects1.length = k;}if ( gdjs.LevelCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossTopArmObjects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossTopArmObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition2IsTrue_0.val = true;
        gdjs.LevelCode.GDBossTopArmObjects1[k] = gdjs.LevelCode.GDBossTopArmObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossTopArmObjects1.length = k;}}
}
if (gdjs.LevelCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.LevelCode.eventsList24(runtimeScene);} //End of subevents
}

}


};gdjs.LevelCode.eventsList26 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BossBody"), gdjs.LevelCode.GDBossBodyObjects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBodyObjects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBodyObjects1[i].getX() <= gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + 32 ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBodyObjects1[k] = gdjs.LevelCode.GDBossBodyObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBodyObjects1.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossBodyObjects1 */
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.LevelCode.GDBossBodyObjects1.length === 0 ) ? 0 :gdjs.LevelCode.GDBossBodyObjects1[0].getPointX("")) - 32, "", 0);
}
{ //Subevents
gdjs.LevelCode.eventsList25(runtimeScene);} //End of subevents
}

}


};gdjs.LevelCode.eventsList27 = function(runtimeScene) {

{


gdjs.LevelCode.eventsList8(runtimeScene);
}


{


gdjs.LevelCode.eventsList13(runtimeScene);
}


{


gdjs.LevelCode.eventsList15(runtimeScene);
}


{


gdjs.LevelCode.eventsList16(runtimeScene);
}


{


gdjs.LevelCode.eventsList19(runtimeScene);
}


{


gdjs.LevelCode.eventsList26(runtimeScene);
}


};

gdjs.LevelCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.LevelCode.GDPlayerObjects1.length = 0;
gdjs.LevelCode.GDPlayerObjects2.length = 0;
gdjs.LevelCode.GDPlayerObjects3.length = 0;
gdjs.LevelCode.GDPlayerObjects4.length = 0;
gdjs.LevelCode.GDPlayerObjects5.length = 0;
gdjs.LevelCode.GDPlayerObjects6.length = 0;
gdjs.LevelCode.GDSpaceBackgroundObjects1.length = 0;
gdjs.LevelCode.GDSpaceBackgroundObjects2.length = 0;
gdjs.LevelCode.GDSpaceBackgroundObjects3.length = 0;
gdjs.LevelCode.GDSpaceBackgroundObjects4.length = 0;
gdjs.LevelCode.GDSpaceBackgroundObjects5.length = 0;
gdjs.LevelCode.GDSpaceBackgroundObjects6.length = 0;
gdjs.LevelCode.GDCorridorBackgroundObjects1.length = 0;
gdjs.LevelCode.GDCorridorBackgroundObjects2.length = 0;
gdjs.LevelCode.GDCorridorBackgroundObjects3.length = 0;
gdjs.LevelCode.GDCorridorBackgroundObjects4.length = 0;
gdjs.LevelCode.GDCorridorBackgroundObjects5.length = 0;
gdjs.LevelCode.GDCorridorBackgroundObjects6.length = 0;
gdjs.LevelCode.GDAsteroidObjects1.length = 0;
gdjs.LevelCode.GDAsteroidObjects2.length = 0;
gdjs.LevelCode.GDAsteroidObjects3.length = 0;
gdjs.LevelCode.GDAsteroidObjects4.length = 0;
gdjs.LevelCode.GDAsteroidObjects5.length = 0;
gdjs.LevelCode.GDAsteroidObjects6.length = 0;
gdjs.LevelCode.GDEnemy2Objects1.length = 0;
gdjs.LevelCode.GDEnemy2Objects2.length = 0;
gdjs.LevelCode.GDEnemy2Objects3.length = 0;
gdjs.LevelCode.GDEnemy2Objects4.length = 0;
gdjs.LevelCode.GDEnemy2Objects5.length = 0;
gdjs.LevelCode.GDEnemy2Objects6.length = 0;
gdjs.LevelCode.GDPlayerBulletObjects1.length = 0;
gdjs.LevelCode.GDPlayerBulletObjects2.length = 0;
gdjs.LevelCode.GDPlayerBulletObjects3.length = 0;
gdjs.LevelCode.GDPlayerBulletObjects4.length = 0;
gdjs.LevelCode.GDPlayerBulletObjects5.length = 0;
gdjs.LevelCode.GDPlayerBulletObjects6.length = 0;
gdjs.LevelCode.GDHealthPackObjects1.length = 0;
gdjs.LevelCode.GDHealthPackObjects2.length = 0;
gdjs.LevelCode.GDHealthPackObjects3.length = 0;
gdjs.LevelCode.GDHealthPackObjects4.length = 0;
gdjs.LevelCode.GDHealthPackObjects5.length = 0;
gdjs.LevelCode.GDHealthPackObjects6.length = 0;
gdjs.LevelCode.GDExplosionObjects1.length = 0;
gdjs.LevelCode.GDExplosionObjects2.length = 0;
gdjs.LevelCode.GDExplosionObjects3.length = 0;
gdjs.LevelCode.GDExplosionObjects4.length = 0;
gdjs.LevelCode.GDExplosionObjects5.length = 0;
gdjs.LevelCode.GDExplosionObjects6.length = 0;
gdjs.LevelCode.GDEnemy3Objects1.length = 0;
gdjs.LevelCode.GDEnemy3Objects2.length = 0;
gdjs.LevelCode.GDEnemy3Objects3.length = 0;
gdjs.LevelCode.GDEnemy3Objects4.length = 0;
gdjs.LevelCode.GDEnemy3Objects5.length = 0;
gdjs.LevelCode.GDEnemy3Objects6.length = 0;
gdjs.LevelCode.GDEnemyBulletObjects1.length = 0;
gdjs.LevelCode.GDEnemyBulletObjects2.length = 0;
gdjs.LevelCode.GDEnemyBulletObjects3.length = 0;
gdjs.LevelCode.GDEnemyBulletObjects4.length = 0;
gdjs.LevelCode.GDEnemyBulletObjects5.length = 0;
gdjs.LevelCode.GDEnemyBulletObjects6.length = 0;
gdjs.LevelCode.GDEnemy1Objects1.length = 0;
gdjs.LevelCode.GDEnemy1Objects2.length = 0;
gdjs.LevelCode.GDEnemy1Objects3.length = 0;
gdjs.LevelCode.GDEnemy1Objects4.length = 0;
gdjs.LevelCode.GDEnemy1Objects5.length = 0;
gdjs.LevelCode.GDEnemy1Objects6.length = 0;
gdjs.LevelCode.GDAttackFlameObjects1.length = 0;
gdjs.LevelCode.GDAttackFlameObjects2.length = 0;
gdjs.LevelCode.GDAttackFlameObjects3.length = 0;
gdjs.LevelCode.GDAttackFlameObjects4.length = 0;
gdjs.LevelCode.GDAttackFlameObjects5.length = 0;
gdjs.LevelCode.GDAttackFlameObjects6.length = 0;
gdjs.LevelCode.GDLifebarContainerObjects1.length = 0;
gdjs.LevelCode.GDLifebarContainerObjects2.length = 0;
gdjs.LevelCode.GDLifebarContainerObjects3.length = 0;
gdjs.LevelCode.GDLifebarContainerObjects4.length = 0;
gdjs.LevelCode.GDLifebarContainerObjects5.length = 0;
gdjs.LevelCode.GDLifebarContainerObjects6.length = 0;
gdjs.LevelCode.GDLifebarObjects1.length = 0;
gdjs.LevelCode.GDLifebarObjects2.length = 0;
gdjs.LevelCode.GDLifebarObjects3.length = 0;
gdjs.LevelCode.GDLifebarObjects4.length = 0;
gdjs.LevelCode.GDLifebarObjects5.length = 0;
gdjs.LevelCode.GDLifebarObjects6.length = 0;
gdjs.LevelCode.GDPlayerAttackAreaObjects1.length = 0;
gdjs.LevelCode.GDPlayerAttackAreaObjects2.length = 0;
gdjs.LevelCode.GDPlayerAttackAreaObjects3.length = 0;
gdjs.LevelCode.GDPlayerAttackAreaObjects4.length = 0;
gdjs.LevelCode.GDPlayerAttackAreaObjects5.length = 0;
gdjs.LevelCode.GDPlayerAttackAreaObjects6.length = 0;
gdjs.LevelCode.GDTilesMechanical2Objects1.length = 0;
gdjs.LevelCode.GDTilesMechanical2Objects2.length = 0;
gdjs.LevelCode.GDTilesMechanical2Objects3.length = 0;
gdjs.LevelCode.GDTilesMechanical2Objects4.length = 0;
gdjs.LevelCode.GDTilesMechanical2Objects5.length = 0;
gdjs.LevelCode.GDTilesMechanical2Objects6.length = 0;
gdjs.LevelCode.GDTilesMechanical1Objects1.length = 0;
gdjs.LevelCode.GDTilesMechanical1Objects2.length = 0;
gdjs.LevelCode.GDTilesMechanical1Objects3.length = 0;
gdjs.LevelCode.GDTilesMechanical1Objects4.length = 0;
gdjs.LevelCode.GDTilesMechanical1Objects5.length = 0;
gdjs.LevelCode.GDTilesMechanical1Objects6.length = 0;
gdjs.LevelCode.GDChangeButtonObjects1.length = 0;
gdjs.LevelCode.GDChangeButtonObjects2.length = 0;
gdjs.LevelCode.GDChangeButtonObjects3.length = 0;
gdjs.LevelCode.GDChangeButtonObjects4.length = 0;
gdjs.LevelCode.GDChangeButtonObjects5.length = 0;
gdjs.LevelCode.GDChangeButtonObjects6.length = 0;
gdjs.LevelCode.GDBossBodyObjects1.length = 0;
gdjs.LevelCode.GDBossBodyObjects2.length = 0;
gdjs.LevelCode.GDBossBodyObjects3.length = 0;
gdjs.LevelCode.GDBossBodyObjects4.length = 0;
gdjs.LevelCode.GDBossBodyObjects5.length = 0;
gdjs.LevelCode.GDBossBodyObjects6.length = 0;
gdjs.LevelCode.GDBossTopArmObjects1.length = 0;
gdjs.LevelCode.GDBossTopArmObjects2.length = 0;
gdjs.LevelCode.GDBossTopArmObjects3.length = 0;
gdjs.LevelCode.GDBossTopArmObjects4.length = 0;
gdjs.LevelCode.GDBossTopArmObjects5.length = 0;
gdjs.LevelCode.GDBossTopArmObjects6.length = 0;
gdjs.LevelCode.GDBossBottomArmObjects1.length = 0;
gdjs.LevelCode.GDBossBottomArmObjects2.length = 0;
gdjs.LevelCode.GDBossBottomArmObjects3.length = 0;
gdjs.LevelCode.GDBossBottomArmObjects4.length = 0;
gdjs.LevelCode.GDBossBottomArmObjects5.length = 0;
gdjs.LevelCode.GDBossBottomArmObjects6.length = 0;
gdjs.LevelCode.GDBossSuperLaserObjects1.length = 0;
gdjs.LevelCode.GDBossSuperLaserObjects2.length = 0;
gdjs.LevelCode.GDBossSuperLaserObjects3.length = 0;
gdjs.LevelCode.GDBossSuperLaserObjects4.length = 0;
gdjs.LevelCode.GDBossSuperLaserObjects5.length = 0;
gdjs.LevelCode.GDBossSuperLaserObjects6.length = 0;
gdjs.LevelCode.GDBossBackgroundObjects1.length = 0;
gdjs.LevelCode.GDBossBackgroundObjects2.length = 0;
gdjs.LevelCode.GDBossBackgroundObjects3.length = 0;
gdjs.LevelCode.GDBossBackgroundObjects4.length = 0;
gdjs.LevelCode.GDBossBackgroundObjects5.length = 0;
gdjs.LevelCode.GDBossBackgroundObjects6.length = 0;
gdjs.LevelCode.GDFadeObjects1.length = 0;
gdjs.LevelCode.GDFadeObjects2.length = 0;
gdjs.LevelCode.GDFadeObjects3.length = 0;
gdjs.LevelCode.GDFadeObjects4.length = 0;
gdjs.LevelCode.GDFadeObjects5.length = 0;
gdjs.LevelCode.GDFadeObjects6.length = 0;
gdjs.LevelCode.GDGameOverObjects1.length = 0;
gdjs.LevelCode.GDGameOverObjects2.length = 0;
gdjs.LevelCode.GDGameOverObjects3.length = 0;
gdjs.LevelCode.GDGameOverObjects4.length = 0;
gdjs.LevelCode.GDGameOverObjects5.length = 0;
gdjs.LevelCode.GDGameOverObjects6.length = 0;

gdjs.LevelCode.eventsList27(runtimeScene);

return;

}

gdjs['LevelCode'] = gdjs.LevelCode;
